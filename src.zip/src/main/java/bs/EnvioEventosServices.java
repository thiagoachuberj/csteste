package bs;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.stream.XMLStreamException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import eventos.s1000.ESocial;
import eventos.s1000.ESocial.EvtInfoEmpregador;
import eventos.s1000.ESocial.EvtInfoEmpregador.InfoEmpregador;
import eventos.s1000.ESocial.EvtInfoEmpregador.InfoEmpregador.Inclusao;
import eventos.s1000.TEmpregador;
import eventos.s1000.TIdeCadastro;
import eventos.s1000.TIdePeriodo;
import eventos.s1000.TInfoEmpregador;
import eventos.s1000.TInfoEmpregador.Contato;
import eventos.s1000.TInfoEmpregador.DadosIsencao;
import eventos.s1000.TInfoEmpregador.InfoComplementares;
import eventos.s1000.TInfoEmpregador.InfoComplementares.SituacaoPF;
import eventos.s1000.TInfoEmpregador.InfoComplementares.SituacaoPJ;
import eventos.s1000.TInfoEmpregador.InfoOP;
import eventos.s1000.TInfoEmpregador.InfoOP.InfoEFR;
import eventos.s1000.TInfoEmpregador.InfoOP.InfoEnte;
import eventos.s1000.TInfoEmpregador.InfoOrgInternacional;
import exception.BusinessException;
import message.SystemPropertiesMessage;
import vo.BaseVO;
import vo.EntradaEnvioVO;
import vo.RetornoEnvioVO;
import xml.XmlDocumentBuildFactory;
import xml.XmlValidationResolver;

public class EnvioEventosServices implements IEnvioEventosService {
	private static final Logger LOGGER = Logger.getLogger(EnvioEventosServices.class);
	private XmlDocumentBuildFactory xmlFactory;
	private SystemPropertiesMessage properties;
	
	public EnvioEventosServices() throws SAXException, IOException, XMLStreamException {
		properties = SystemPropertiesMessage.getInstance();
		System.setProperty("jdk.xml.maxOccurLimit", "10000");
		xmlFactory = new XmlDocumentBuildFactory(new XmlValidationResolver(SystemPropertiesMessage.getSystemEnvOrProperty("arquivosXSD")));
	}
	
	public EnvioEventosServices(String pathXSD) throws SAXException, IOException, XMLStreamException {
		properties = SystemPropertiesMessage.getInstance();
		System.setProperty("jdk.xml.maxOccurLimit", "10000");
		xmlFactory = new XmlDocumentBuildFactory(new XmlValidationResolver(SystemPropertiesMessage.getSystemEnvOrProperty("arquivosXSD")));		
	}
	
	public RetornoEnvioVO enviarLoteEventos(EntradaEnvioVO entrada) throws BusinessException {
		try {			
			RetornoEnvioVO retornoEnvioVO = new RetornoEnvioVO();
			List<String> lstEventosAssinados = null;
			
			if(entrada != null) {
				AssinaturaEventos assinaturaEventos = new AssinaturaEventos(xmlFactory);
				lstEventosAssinados = assinaturaEventos.assina(entrada.getLstEventosVO());
				
				if(lstEventosAssinados != null && !lstEventosAssinados.isEmpty()) {
					String loteEventos = null;
					
					loteEventos = MontagemLote.montaLote(lstEventosAssinados, entrada.getGrupoLote(), entrada.getNumeroEmissor(), entrada.getNumeroTransmissor());
					
					if(loteEventos != null) {
						ProcessoEnvioLote processaEnvioLotes = new ProcessoEnvioLote(properties);
						retornoEnvioVO = processaEnvioLotes.processa(loteEventos);					
					}
					else {
						throw new BusinessException("Ocorreu um problema ao tentar criar o Lote.");	
					}
				}
				else {
					throw new BusinessException("Eventos não localizados para efetuar o envio.");
				}
			}
			else {
				throw new BusinessException("Objeto EntradaEnvioVO é vazio ou nulo");
			}
			
			return retornoEnvioVO;
		}
		catch(Exception ex) {
			LOGGER.error("Erro no metodo enviarLoteEventos(EntradaEnvioVO entrada): ", ex);
			throw new BusinessException("Erro no metodo enviarLoteEventos(EntradaEnvioVO entrada): ", ex);
		}
	}
	
	/*public RetornoEnvioVO enviarLoteEventos(EntradaEnvioVO entrada) throws BusinessException {
		try {
			RetornoEnvioVO retornoEnvioVO = new RetornoEnvioVO();
			List<String> lstEventosAssinados = null;
			
			if(entrada != null) {
				AssinaturaEventos assinaturaEventos = new AssinaturaEventos(xmlFactory);
				lstEventosAssinados = assinaturaEventos.assina(entrada.getLstEventosVO());
				
				if(lstEventosAssinados != null && !lstEventosAssinados.isEmpty()) {
//				if(entrada.getLstEventosVO() != null && !entrada.getLstEventosVO().isEmpty()) {
					String loteEventos = null;

					ESocial loteEnvio = new ESocial();
					EnvioLoteEventos envioLoteEventos = new EnvioLoteEventos();
					envioLoteEventos.setGrupo(Integer.parseInt(entrada.getGrupoLote()));
					TIdeEmpregador idEmpregador = new TIdeEmpregador();
					idEmpregador.setTpInsc(entrada.getNumeroEmissor().length() > 11 ? new Byte("1") : new Byte("2"));
					idEmpregador.setNrInsc(entrada.getNumeroEmissor());
					envioLoteEventos.setIdeEmpregador(idEmpregador);
					TIdeTransmissor ideTransmissor = new TIdeTransmissor();
					ideTransmissor.setTpInsc(entrada.getNumeroTransmissor().length() > 11 ? new Byte("1") : new Byte("2"));
					ideTransmissor.setNrInsc(entrada.getNumeroTransmissor());
					envioLoteEventos.setIdeTransmissor(ideTransmissor);
					
					Eventos eventos = new Eventos();
					for(String str : lstEventosAssinados) {
						String idEvento = str.substring(str.indexOf("Id=\"") + 4, str.indexOf("Id=\"") + 40 );
						TArquivoEsocial evento = new TArquivoEsocial();
						evento.setId(idEvento);
						evento.setAny(Util.convertStringToElement(str));
						eventos.getEvento().add(evento);
					}
					
					envioLoteEventos.setEventos(eventos);
					loteEnvio.setEnvioLoteEventos(envioLoteEventos);
					
					loteEventos = MontaXML.montaXML(loteEnvio);
					
					if(loteEventos != null) {
						ProcessoEnvioLote processaEnvioLotes = new ProcessoEnvioLote(properties);
						retornoEnvioVO = processaEnvioLotes.processa(loteEventos);					
					}
					else {
						throw new BusinessException("Ocorreu um problema ao tentar criar o Lote.");	
					}
				}
				else {
					throw new BusinessException("Eventos não localizados para efetuar o envio.");
				}
			}
			
			return retornoEnvioVO;
		}
		catch(IOException ex) {
			LOGGER.error("Erro no metodo enviarLoteEventos(EntradaEnvioVO entrada): ", ex);
			throw new BusinessException("Erro no metodo enviarLoteEventos(EntradaEnvioVO entrada): ", ex);
		}
	}*/
	
	@Override
	public RetornoEnvioVO removerEmpregador(String cpfCnpjEmpregador, String cpfCnpjTransmissor) throws BusinessException {
		if((!"".equals(cpfCnpjEmpregador) && cpfCnpjEmpregador != null) &&
				(!"".equals(cpfCnpjTransmissor) && cpfCnpjTransmissor != null)) {
			BaseVO eventoVO = montaDadosEventoCadastroEvtInfoEmpregador(cpfCnpjEmpregador.length() > 11 ? "1" : "2", cpfCnpjEmpregador);
			List<BaseVO> lstEvntoVO = new ArrayList<>();
			lstEvntoVO.add(eventoVO);
			
			AssinaturaEventos assinaturaEventos = new AssinaturaEventos(xmlFactory);
			List<String> lstEventosAssinados = assinaturaEventos.assina(lstEvntoVO);
			String loteEventos = MontagemLote.montaLote(lstEventosAssinados, "1", cpfCnpjEmpregador, cpfCnpjTransmissor);
			
			if(loteEventos != null) {
				ProcessoEnvioLote processaEnvioLotes = new ProcessoEnvioLote(properties);
				return processaEnvioLotes.processa(loteEventos);					
			}
			else {
				throw new BusinessException("Ocorreu um problema ao tentar criar o Lote.");	
			}
		}
		else {
			throw new BusinessException("O CPFCNPJEMPREGADOR ou CPFCNPJTRANSMISSOR não foi informado ou é nulo.");
		}
	}
	
	private BaseVO montaDadosEventoCadastroEvtInfoEmpregador(String tpEmpregador, String nrEmpregador) {
			ESocial eSocialEvtInfoEmpregador = new ESocial();
			EvtInfoEmpregador evtInfoEmpregador = new EvtInfoEmpregador();
			
			//montando ID:
			StringBuilder sb = montaIDEvento(tpEmpregador, nrEmpregador);
			evtInfoEmpregador.setId(sb.toString());
			
			TEmpregador empregador = new TEmpregador();
			empregador.setNrInsc(nrEmpregador);
			empregador.setTpInsc(new Byte(tpEmpregador));
			evtInfoEmpregador.setIdeEmpregador(empregador);
			
			TIdeCadastro value = new TIdeCadastro();
			value.setProcEmi(new Byte("0"));
			value.setTpAmb(new Byte("2"));
			value.setVerProc("0");
			evtInfoEmpregador.setIdeEvento(value);
			
			InfoEmpregador empregador2 = new InfoEmpregador();
			Inclusao inclusao = new Inclusao();
			TIdePeriodo idePeriodo = new TIdePeriodo();
			idePeriodo.setIniValid("2017-01");
			idePeriodo.setFimValid("2017-02");
			inclusao.setIdePeriodo(idePeriodo);
			
			// preencher os dados obrigatorios
			TInfoEmpregador tinfoEmpregador = new TInfoEmpregador();
			tinfoEmpregador.setClassTrib("00");
			tinfoEmpregador.setNmRazao("RemoverEmpregadorDaBaseDeDadosDaProducaoRestrita");
			tinfoEmpregador.setIndConstr(new Byte("0"));
			tinfoEmpregador.setIndCoop(new Byte("0"));
			tinfoEmpregador.setIndDesFolha(new Byte("0"));
			tinfoEmpregador.setIndEntEd("N");
			tinfoEmpregador.setIndEtt("N");
			tinfoEmpregador.setIndOptRegEletron(new Byte("0"));
			tinfoEmpregador.setNatJurid("0000");
			tinfoEmpregador.setNrRegEtt("12345678910");
			
			Contato contato = new Contato();
			contato.setCpfCtt("09063372752");
			contato.setEmail("thiago@thiago.com");
			contato.setFoneCel("21999999999");
			contato.setNmCtt("testeContato");
			contato.setFoneFixo("2122222222");
			tinfoEmpregador.setContato(contato);
			
			DadosIsencao dadosIsencao = new DadosIsencao();
			GregorianCalendar gc = new GregorianCalendar();
			//gc.setTime(new Date());
			
			dadosIsencao.setDtDou(toXMLGregorianCalendar(gc.getTime()));
			dadosIsencao.setDtEmisCertif(toXMLGregorianCalendar(gc.getTime()));
			dadosIsencao.setDtProtRenov(toXMLGregorianCalendar(gc.getTime()));
			dadosIsencao.setDtVencCertif(toXMLGregorianCalendar(gc.getTime()));
			dadosIsencao.setIdeMinLei("ok");
			dadosIsencao.setNrCertif("numero");
			dadosIsencao.setNrProtRenov("numero");
			dadosIsencao.setPagDou(new BigInteger("10"));
			tinfoEmpregador.setDadosIsencao(dadosIsencao);
			
			InfoComplementares ip = new InfoComplementares();
			SituacaoPF sitPF = new SituacaoPF();
			sitPF.setIndSitPF(new Byte("0"));
			ip.setSituacaoPF(sitPF);
			SituacaoPJ pj = new SituacaoPJ();
			pj.setIndSitPJ(new Byte("0"));
			ip.setSituacaoPJ(pj);
			tinfoEmpregador.setInfoComplementares(ip);
			
			InfoOP info = new InfoOP();
			InfoEFR efr = new InfoEFR();
			efr.setCnpjEFR("12345678912345");
			efr.setIdeEFR("S");
			info.setInfoEFR(efr);
			InfoEnte ente = new InfoEnte();
			ente.setCodMunic(new BigInteger("10"));
			ente.setIndRPPS("S");
			ente.setNmEnte("ENTE");
			ente.setUf("RJ");
			ente.setVrSubteto(new BigDecimal("10"));
			ente.setSubteto(new Byte("0"));
			info.setInfoEnte(ente);
			info.setNrSiafi("789");
			info.setInfoEnte(ente);
			tinfoEmpregador.setInfoOP(info);
			
			InfoOrgInternacional infoOrg = new InfoOrgInternacional();
			infoOrg.setIndAcordoIsenMulta(new Byte("0"));
			tinfoEmpregador.setInfoOrgInternacional(infoOrg);
			
			inclusao.setInfoCadastro(tinfoEmpregador);
			empregador2.setInclusao(inclusao);
			evtInfoEmpregador.setInfoEmpregador(empregador2);
			
			eSocialEvtInfoEmpregador.setEvtInfoEmpregador(evtInfoEmpregador);
		
		return eSocialEvtInfoEmpregador;
	}
	
	private XMLGregorianCalendar toXMLGregorianCalendar(Date date) { 
        GregorianCalendar gCalendar = new GregorianCalendar();
        gCalendar.setTime(date);
        XMLGregorianCalendar xmlCalendar = null;
        
        try {
            Date dob=null;
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            String str = df.format( date );
            dob = df.parse(str);
            GregorianCalendar cal = new GregorianCalendar();
            cal.setTime(dob);
            xmlCalendar = DatatypeFactory.newInstance().
            		newXMLGregorianCalendarDate(
            				cal.get(Calendar.YEAR), 
            				cal.get(Calendar.MONTH)+1, 
            				cal.get(Calendar.DAY_OF_MONTH), 
            				DatatypeConstants.FIELD_UNDEFINED);
        }
        catch (DatatypeConfigurationException ex) {
        	ex.printStackTrace();
        } 
        catch (ParseException e) {
			e.printStackTrace();
		}
        return xmlCalendar;
    }

	private StringBuilder montaIDEvento(String tpEmpregador, String nrEmpregador) {
		StringBuilder sb = new StringBuilder("ID");
		sb.append(tpEmpregador).append(nrEmpregador.length() == 11 ? nrEmpregador+"000" : nrEmpregador);
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddhhmmss");
		sb.append(sdf.format(new Date())).append("00001");
		return sb;
	}
	
	public static void main(String []args) throws SAXException, IOException, XMLStreamException {
		new XmlDocumentBuildFactory(new XmlValidationResolver(SystemPropertiesMessage.getInstance().getValueKey("arquivosXSD")));
		System.out.println("alive");
	}
}